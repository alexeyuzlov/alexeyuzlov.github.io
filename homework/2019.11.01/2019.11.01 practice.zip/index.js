const app = require('./src/app');

const result = app();
console.info(result);
